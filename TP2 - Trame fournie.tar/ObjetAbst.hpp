#ifndef OBJETABST_HPP
#define OBJETABST_HPP

#endif /* OBJETABST_HPP */

